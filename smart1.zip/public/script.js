// Elements
const menuBtn = document.getElementById('menu-btn');
const sidebar = document.getElementById('sidebar');
const chatContainer = document.getElementById('chat-container');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const newChatBtn = document.getElementById('new-chat-btn');
const historyList = document.getElementById('history-list');
const loginBtn = document.getElementById('login-btn');

// Security Key (Must match your Server/ENV)
const myApiKey = "adventure_super_secret_key_998877"; 

// 1. Sidebar Toggle
menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
});

// 2. New Chat Logic
newChatBtn.addEventListener('click', () => {
    chatContainer.innerHTML = ''; 
    addMessage("Hello! I'm your Smart Academic Assistant. Let's start a fresh topic!", 'bot');
});

// 3. Add Message to UI
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);
    const avatarIcon = sender === 'user' ? 'fa-user' : 'fa-sparkles';
    const formattedText = text.replace(/\n/g, '<br>');

    messageDiv.innerHTML = `
        <div class="avatar"><i class="fas ${avatarIcon}"></i></div>
        <div class="message-content">
            <p>${formattedText}</p>
        </div>
    `;

    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// 4. Update Recent History Sidebar
function addToHistory(text) {
    const historyItem = document.createElement('div');
    historyItem.classList.add('history-item');
    historyItem.innerHTML = `<i class="far fa-message"></i> ${text}`;
    
    // Clicking a history item re-asks the question
    historyItem.addEventListener('click', () => {
        userInput.value = text;
        handleSend();
    });

    historyList.prepend(historyItem); // Add most recent to top
}

// 5. Handle Send Logic
async function handleSend() {
    const text = userInput.value.trim();
    if (text === '') return;

    addMessage(text, 'user');
    addToHistory(text); // Track in sidebar
    userInput.value = ''; 

    // Thinking placeholder
    const typingDiv = document.createElement('div');
    typingDiv.classList.add('message', 'bot');
    typingDiv.innerHTML = `
        <div class="avatar"><i class="fas fa-sparkles"></i></div>
        <div class="message-content"><p><i>Thinking...</i></p></div>
    `;
    chatContainer.appendChild(typingDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;

    try {
        const response = await fetch('http://localhost:3000/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': myApiKey
            },
            body: JSON.stringify({ message: text })
        });

        const data = await response.json();
        chatContainer.removeChild(typingDiv);

        if (data.error) {
            addMessage("Error: " + data.error, 'bot');
        } else {
            addMessage(data.reply, 'bot');
        }

    } catch (error) {
        chatContainer.removeChild(typingDiv);
        addMessage("⚠️ Server Error. Check if your Node terminal is running!", 'bot');
    }
}

// Event Listeners
sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSend(); });
loginBtn.addEventListener('click', () => alert("Login System Integration Coming Soon!"));