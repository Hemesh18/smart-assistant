const { GoogleGenerativeAI } = require('@google/generative-ai');

// 1. Put your actual Google Key here inside the quotes
const MY_KEY = "AIzaSyBYIsfq4zNaADEn3Jld2y_vJhbN-SZoJvY"; 

const genAI = new GoogleGenerativeAI(MY_KEY);

// We will test the classic, most reliable model first
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

async function runTest() {
    console.log("Connecting to Google...");
    try {
        const result = await model.generateContent("Hello! Are you working?");
        console.log("SUCCESS! Google says: " + result.response.text());
    } catch (error) {
        console.error("FAILED. The exact error is:", error.message);
    }
}

runTest();