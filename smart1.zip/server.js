const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

// --- 1. PUT YOUR KEYS DIRECTLY HERE ---
const MY_FRONTEND_PASSWORD = "adventure_super_secret_key_998877";
const MY_GOOGLE_GEMINI_KEY = "AIzaSyBYIsfq4zNaADEn3Jld2y_vJhbN-SZoJvY"; // <--- Put your actual Google API key here!
// --------------------------------------

// Gemini AI Setup
const { GoogleGenerativeAI } = require('@google/generative-ai');
const genAI = new GoogleGenerativeAI(MY_GOOGLE_GEMINI_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // This fixes the CORS file:/// error!

// Database Connection
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '', // Assuming standard XAMPP setup
    database: 'travel_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// API Key Security
const authenticateAPIKey = (req, res, next) => {
    const providedKey = req.header('x-api-key');
    if (!providedKey || providedKey !== MY_FRONTEND_PASSWORD) {
        return res.status(401).json({ error: "Unauthorized: Invalid or missing API Key." });
    }
    next(); 
};

app.use(authenticateAPIKey);

// Chatbot Route
app.post('/api/chat', async (req, res) => {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required." });

    try {
        const prompt = `You are a Smart Academic Assistant. Be helpful, concise, and polite. The user says: "${message}"`;
        const result = await model.generateContent(prompt);
        const aiResponse = result.response.text();
        res.json({ reply: aiResponse });
    } catch (error) {
        console.error("Gemini API Error:", error);
        res.status(500).json({ error: "Failed to generate a response from the AI." });
    }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(`API Key protection is ENABLED.`);
});